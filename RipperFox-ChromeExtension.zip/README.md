# RipperFoxExtensios
The firefox add-on part of RipperFox

## Install
1. Go to chrome://extension
2. Enable Developer mode (Right top corner) 
3. Click load unpacked
4. Navigate to your 

## Install 
1. Download this git repo 

asdfasdfasdf